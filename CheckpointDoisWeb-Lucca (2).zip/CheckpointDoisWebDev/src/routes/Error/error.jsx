
export default function Error() {

    return (
      <>
        <h1>Erro 404 - Página não encontrada</h1>
      </>
    )
  }
  